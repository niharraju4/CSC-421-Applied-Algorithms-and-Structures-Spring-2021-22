from functools import reduce


def getConvexHull(points):
    TURN_LEFT, TURN_RIGHT, TURN_NONE = (1, -1, 0)

    def cmp(n, t):
        return (n > t) - (n < t)

    def turn(x, y, z):
        return cmp((y[0] - x[0]) * (z[1] - x[1]) - (z[0] - x[0]) * (y[1] - x[1]), 0)

    def _keep_left(hull, z):
        while len(hull) > 1 and turn(hull[-2], hull[-1], z) != TURN_LEFT:
            hull.pop()
        if not len(hull) or hull[-1] != z:
            hull.append(z)
        return hull

    points = sorted(points)
    d = reduce(_keep_left, points, [])
    e = reduce(_keep_left, reversed(points), [])
    return d.extend(e[i] for i in range(1, len(e) - 1)) or d



if __name__ == "__main__":
    test_file = input(" Please enter the name of the file containing points here: ")
    with open(test_file) as file:
        points = []
        for line in file.readlines():
            inp = points.append(list(map(int, line.split())))
    print("The co-ordinates are :", *getConvexHull(points))


